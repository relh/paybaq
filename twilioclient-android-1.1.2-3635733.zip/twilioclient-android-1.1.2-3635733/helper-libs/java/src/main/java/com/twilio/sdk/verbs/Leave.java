package com.twilio.sdk.verbs;

public class Leave extends Verb {

    public Leave() {
        super(Verb.V_LEAVE, null);
    }
}

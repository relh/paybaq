package com.twilio.sdk.resource.instance;

public enum Recurrence {
    daily, monthly, yearly
}

module Twilio
  module REST
    class ConnectApps < ListResource; end
    class ConnectApp < InstanceResource; end
  end
end

module Twilio
  module REST
    class Sandbox < InstanceResource; end
  end
end

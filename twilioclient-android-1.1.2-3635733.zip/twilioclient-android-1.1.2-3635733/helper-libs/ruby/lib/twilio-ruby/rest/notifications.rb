module Twilio
  module REST
    class Notifications < ListResource; end
    class Notification < InstanceResource; end
  end
end

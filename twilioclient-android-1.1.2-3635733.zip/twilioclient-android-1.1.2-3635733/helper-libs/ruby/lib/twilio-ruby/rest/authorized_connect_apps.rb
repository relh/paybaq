module Twilio
  module REST
    class AuthorizedConnectApps < ListResource; end
    class AuthorizedConnectApp < InstanceResource; end
  end
end

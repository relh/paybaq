module Twilio
  module REST
    class ShortCodes < ListResource; end
    class ShortCode < InstanceResource; end
  end
end

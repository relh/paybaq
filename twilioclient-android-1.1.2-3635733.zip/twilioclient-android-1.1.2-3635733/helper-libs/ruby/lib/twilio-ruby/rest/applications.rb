module Twilio
  module REST
    class Applications < ListResource; end
    class Application < InstanceResource; end
  end
end

module Twilio
  module REST
    class Transcriptions < ListResource; end
    class Transcription < InstanceResource; end
  end
end
